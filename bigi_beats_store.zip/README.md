
# Bigi Beats Store

## How to use
1. Upload this folder to GitHub
2. Enable GitHub Pages (Settings → Pages)
3. Replace beats in /beats folder
4. Edit prices & names in index.html

## Payments
- Currently buttons are placeholders
- You can connect Paystack, M-Pesa, or Sellfy later
